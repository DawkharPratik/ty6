class ThreadPrio extends Thread
{
  public static void main(String args[])
  {
     ThreadPrio t = new ThreadPrio.currenThread();
     
     System.out.println(t);
     System.out.println("Thread Name "+t.getName());
     System.out.println("Thread Priority "+t.getPriority());
     
     t.setName("Parent");
     t.setPriority(10);
     
     System.out.println(t);
     System.out.println("Thread Name: "+t.getName());
     System.out.println("Thread Priority: "+t.getPriority());
  }
} 
