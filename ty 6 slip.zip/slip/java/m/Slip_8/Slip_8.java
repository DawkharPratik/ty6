import java.lang.String.*;


class Thread1 extends Thread
{
   String msg="";
   int n;
   Thread1(String msg,int n)
   {
      this.msg=msg;
      this.n=n;
   }
   
   public void run()
   {
      try
      {
         for(int i=1;i<=n;i++)
         {
            System.out.println(msg+" "+i+" Times");
         }
         System.out.println("\n");
      }
      catch(Exception e){}
   }
}

class Slip_8
{
   public static void main(String args[])
   {
      
      int n=10;
      
      Thread1 t1 = new Thread1("COVID19",n);
      t1.start();
      Thread1 t2 = new Thread1("LOCKDOWN2020",n+10);
      t2.start();
      Thread1 t3 = new Thread1("VACCINATED2021",n+20);
      t3.start();
   }
}
