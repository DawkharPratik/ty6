import java.util.*;

class Hash
{
  public static void main(String args[])
  {
     Scanner br = new Scanner(System.in);
     
     HashSet<String> fs = new HashSet<>();
     
     System.out.println("Enter number for Storing How many Friends: ");
     int n = br.nextInt();
     
     for(int i=0;i<n;i++)
     {
        System.out.println("Enter Friend Name ");
        String name = br.next();
        fs.add(name);
     }
     
     TreeSet<String> sorted = new TreeSet<>(fs);
     
     System.out.println("Your Friends List is: ");
     
     for(String friend : sorted)
     {
       System.out.println(friend);
     }
  }
}  
