import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class BlinkText extends JFrame implements Runnable {
    JLabel label;

    BlinkText() 
    {
        label = new JLabel("Hello JAVA", JLabel.CENTER);
        add(label, BorderLayout.CENTER);
        setLocationRelativeTo(null);
        setSize(300, 200);
        setVisible(true);
    }

    public void run() 
    {
        try 
        {
            while (true) 
            {
                label.setVisible(false);
                Thread.sleep(500); 
                label.setVisible(true);
                Thread.sleep(500); 
            }
        } catch (InterruptedException e) {}
    }

    public static void main(String args[]) 
    {
        BlinkText blinkText = new BlinkText();
        Thread t1 = new Thread(blinkText);
        t1.start();
    }
}
