import java.util.*;

public class City {
    // Declare Scanner and ArrayList objects outside of main method to make them accessible to other methods
    static Scanner br = new Scanner(System.in);
    static ArrayList<String> cities = new ArrayList<>();
    static ArrayList<String> stdCodes = new ArrayList<>();

    public static void main(String[] args) {
        while (true) {
            System.out.println("\nOptions:");
            System.out.println("1. Add a new city and its code");
            System.out.println("2. Remove a city from the collection");
            System.out.println("3. Search for a city name and display the code");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = br.nextInt();

            switch (choice) {
                case 1:
                    addCity();
                    break;
                case 2:
                    removeCity();
                    break;
                case 3:
                    searchCity();
                    break;
                case 4:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 4.");
            }
        }
    }

    static void addCity() {
        System.out.print("Enter city name: ");
        String city = br.next();
        if (cities.contains(city)) {
            System.out.println("City already exists.");
            return;
        }
        System.out.print("Enter STD code for " + city + ": ");
        String stdCode = br.next();
        cities.add(city);
        stdCodes.add(stdCode);
        System.out.println("City added successfully.");
    }

    static void removeCity() {
        System.out.print("Enter city name to remove: ");
        String city = br.next();
        int index = cities.indexOf(city);
        if (index != -1) {
            cities.remove(index);
            stdCodes.remove(index);
            System.out.println(city + " removed successfully.");
        } else {
            System.out.println("City not found.");
        }
    }

    static void searchCity() 
    {
        System.out.print("Enter city name to search: ");
        String city = br.next();
        int index = cities.indexOf(city);
        if (index != -1)
            System.out.println("STD code for " + city + " is: " + stdCodes.get(index));
        else
            System.out.println("City not found.");       
       
    }
}
