import  java.sql.*;
import  java.awt.*;
import  java.awt.event.*;
import  javax.swing.*;
import  javax.swing.table.*;

class Project extends JFrame implements ActionListener
{
   JLabel l1,l2,l3,l4;
   JTextField f1,f2,f3,f4;
   JPanel p1,p2;
   JButton b1,b2;
   
   JFrame jf;
   DefaultTableModel dtm;
   JTable jt;
   JScrollPane jsp;
   
   Project()
   {
      try
      {
         Class.forName("org.postgresql.Driver");
         Connection cn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/tybcs","postgres","root");         
         Statement st  = cn.Statement();
          String sql1 = "create table Product(pid int primary key, pname varchar(50), pdescription varchar(150), pstatus varchar(20))";
          st.executeUpdate(sql1);
          
          System.out.println("Table is Created Successfuly");
          String sql = "insert into Prject(pid,pname,pdescription,pstatus) values(1,'abc','my project name is xyz','processing')";
          
          st.executeUpdate(sql);
          System.out.println("Record Inserted Successfully");
          
          
