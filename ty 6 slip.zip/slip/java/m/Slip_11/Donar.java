import java.sql.*;

class Donar
{
   public static void main(String args[])throws SQLException,Exception
   {
      try
      {
         Class.forName("org.postgresql.Driver");
         Connection cn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/tybcs","postgres","root");
         Statement st = null;
         ResultSet rs = st.executeQuery("select * from donar");
         ResultSetMetaData rmd = rs.getMetaData();
         
         int n = rmd.getColumnCount();
         System.out.println("Number of Columns in  Donat Table is: "+n);
         
         System.out.println("No\tName\tLabel\tType\tDisplaySize\tReadOnly\tWritable\tNULL");
         for(int i=0;i<n;i++)
	 {
	    System.out.println(i+"\t"+rmd.getColumnName(i)+"\t"+rmd.getColumnLabel(i)+"\t"+rmd.getColumnTypeName(i)+"\t"+      rmd.getColumnDisplaySize(i)+"\t"+rmd.isReadOnly(i)+"\t"+rmd.isWritable(i)+"\t"+rmd.isNullable(i));
	 }
	 cn.close();
	 st.close();
	 rs.close();
	 
      }
      catch(SQLException se)
      {
         System.out.println("Driver not found");
      }	 
  }
}
