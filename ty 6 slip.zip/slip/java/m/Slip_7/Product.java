import java.sql.*;


class Product 
{
   public static void main(String args[])throws SQLException,Exception
   {
      try
      {
         Class.forName("org.postgresql.Driver");
         Connection cn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/tybcs","postgres","root");
         
         Statement st = cn.createStatement();
         
         String sql1 = "create table Product(Pid int primary key, Pname varchar(50), Price decimal(10,2))";
         
         st.executeUpdate(sql1);
         System.out.println("Table is Created Successfuly");
         
         String sql = "insert into Product(Pid,Pname,Price) values(1,'abc',23)";
         st.executeUpdate(sql);
         System.out.println("Record Inserted Successfully");
         
         ResultSet rs = st.executeQuery("select * from Product");
         
         while(rs.next())
         {
              int id = rs.getInt("Pid");
              String name = rs.getString("Pname");
              double price = rs.getDouble("Price");
             
             
              System.out.println("Pid :"+id);
              System.out.println("Pname :"+name);
              System.out.println("Price :"+price);
         }
          rs.close();
          st.close();
          cn.close();
      }
      catch(SQLException se) 
      {
            se.printStackTrace();
      } 
      catch(Exception e) 
      {
            e.printrsStackTrace();
      } 
    }
}             
