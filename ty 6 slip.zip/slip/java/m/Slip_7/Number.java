import java.util.*;

class RandomNumber extends Thread
{
   public void run()
   {
      try
      {
         Random rn = new Random();
         while(true)
         {
             int no = rn.nextInt(100) + 1;
             System.out.println("Random Number is "+no);
         
             if (no % 2 == 0) 
             {
                Even t = new Even(no);
                t.start();
             } 
             else 
             {
                Cube t = new Cube(no);
                t.start();
             }
             Thread.sleep(1000); // Wait for 1 second
         } 
      }
      catch (InterruptedException e) 
      {
          System.out.println("Exception Ocured");
      }
   }
}
    
class Even extends Thread 
{
    int number;

    Even(int number) 
    {
        this.number = number;
    }

    public void run() 
    {
        System.out.println("Square of " + number + " is " + (number * number));
    }
}   

class Cube extends Thread 
{
    int number;

    public Cube(int number) 
    {
        this.number = number;
    }

    public void run() 
    {
        System.out.println("Cube of " + number + " is " + (number * number * number));
    }
}

class Number 
{
    public static void main(String args[]) 
    {
        RandomNumber t = new RandomNumber();
        t.start();
    }
}
