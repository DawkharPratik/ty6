//a11
#include <ctype.h>
#include <stdio.h>

int avail[10];
int max[10][10];
int alloc[10][10];
int need[10][10];
int m,n,i,j;

void get_alloc_state();
void print_alloc_state();

void main()
{ 
    get_alloc_state();  //get avail,max,alloc and find need
    print_alloc_state();
}//main

void get_alloc_state()
{
    printf("\nHow many processes:"); scanf("%d",&n);
    printf("\nHow many resources:"); scanf("%d",&m);
    printf("\nEnter Available Resources:\n");
    for(j=0;j<m;j++) scanf("%d",&avail[j]);
    printf("\nEnter Maximum demand of each process:\n");
    for(i=0;i<n;i++)
    { 
        printf("P%d: ",i);
    for(j=0;j<m;j++)
        scanf("%d",&max[i][j]);
    } 
    printf("\nEnter allocation by each process:\n");
    for(i=0;i<n;i++)
    { 
        printf("P%d: ",i);
        for(j=0;j<m;j++)
            scanf("%d",&alloc[i][j]);
    } 
}

void print_alloc_state()
{   
    printf("\nTotal number of resource types : %d",m);
    printf("\nTotal number of processes:%d",n);
    printf("\n\nAvail instances of each resource type:\n");
	for (j=0; j<m; j++)
	{ 
        printf("%d\t",avail[j]);
	}
	printf("\n\nmaximum demand by each process\n");
	for (i=0; i<n; i++)
	{ 
        printf("Process %d: ",i);
        for (j=0;j<m; j++) printf("%d\t",max[i][j]);
        printf("\n");
	}
	printf("\n\n allocation by each process\n");
	for (i=0; i<n; i++)
	{ 
        printf("Process %d: ",i);
        for (j=0;j<m; j++) printf("%d\t",alloc[i][j]);
        printf("\n");
	}
	//calcu and printneed
	printf("\n\nNeed by each process\n");
	for (i=0; i<n; i++)
	{ 
        printf("Process %d: ",i);
        for (j=0;j<m; j++)
        { 
            need[i][j]=max[i][j]-alloc[i][j];
            printf("%4d",need[i][j]);
        }
        printf("\n");
	}
}//get_alloc_state