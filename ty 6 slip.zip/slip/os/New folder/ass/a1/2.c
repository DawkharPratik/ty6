#include <stdio.h>

int avail[] = {3, 3, 2}, work[3], max[5][3] = {{7, 5, 3}, {3, 2, 2}, {9, 0, 2}, {2, 2, 2}, {4, 3, 3}};
int alloc[5][3] = {{0, 1, 0}, {2, 0, 0}, {3, 0, 2}, {2, 1, 1}, {0, 0, 2}};
int need[5][3], finish[5], safeseq[5], m = 3, n = 5, ssi = -1, i, j;

void print_alloc_state();
void print_safess();

void main() {
    print_alloc_state();
    int found;
    for (j = 0; j < m; j++) work[j] = avail[j];
    for (i = 0; i < n; i++) finish[i] = 0;
    printf("\n\nChecking for safe state...");
    do {
        found = 0;
        for (i = 0; i < n; i++) {
            if (!finish[i]) {
                int need_lte_work = 1;
                for (j = 0; j < m; j++)
                    if (need[i][j] > work[j]) {
                        need_lte_work = 0;
                        break;
                    }
                if (need_lte_work) {
                    printf("\nSelected Process %d", i);
                    finish[i] = 1;
                    for (j = 0; j < m; j++) work[j] += alloc[i][j];
                    safeseq[++ssi] = i;
                    found = 1;
                    break;
                }
            }
        }
        if (!found) {
            for (i = 0; i < n; i++)
                if (!finish[i]) {
                    printf("\nSystem is not in a safe state.\n");
                    return;
                }
            printf("\nSystem is in a safe state.");
            print_safess();
            return;
        }
    } while (1);
}

void print_alloc_state() {
    printf("\nTotal number of resource types: %d", m);
    printf("\nTotal number of processes: %d\n", n);
    printf("\nAvailable instances of each resource type:\n");
    for (j = 0; j < m; j++) printf("%d\t", avail[j]);
    printf("\n\nMaximum demand by each process:\n");
    for (i = 0; i < n; i++) {
        printf("Process %d: ", i);
        for (j = 0; j < m; j++) printf("%d\t", max[i][j]);
        printf("\n");
    }
    printf("\nAllocation by each process:\n");
    for (i = 0; i < n; i++) {
        printf("Process %d: ", i);
        for (j = 0; j < m; j++) printf("%d\t", alloc[i][j]);
        printf("\n");
    }
    printf("\nNeed by each process:\n");
    for (i = 0; i < n; i++) {
        printf("Process %d: ", i);
        for (j = 0; j < m; j++) {
            need[i][j] = max[i][j] - alloc[i][j];
            printf("%4d", need[i][j]);
        }
        printf("\n");
    }
}

void print_safess() {
    printf("\nSafe Sequence : ");
    for (i = 0; i <= ssi; i++) printf("%4d", safeseq[i]);
}
