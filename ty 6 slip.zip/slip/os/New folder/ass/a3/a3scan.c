#include <stdio.h>
#include <stdlib.h>

int main() {
    int request[] = {98, 183, 41, 122, 14, 124, 65, 67};
    int n = 8, hpos = 53, firstt = 0, lastt = 199, thmov = 0;

    // Sort requests in ascending order
    for (int i = 0; i < n - 1; i++)
        for (int j = 0; j < n - i - 1; j++)
            if (request[j] > request[j + 1]) {
                int temp = request[j];
                request[j] = request[j + 1];
                request[j + 1] = temp;
            }

    // Scan towards right direction
    int j = 0;
    while (request[j] < hpos) j++;

    thmov += abs(request[j] - hpos);
    printf("Current head position: %d\n", hpos);

    for (int i = j; i < n; i++) {
        thmov += abs(request[i] - hpos);
        hpos = request[i];
        printf("Current head position: %d\n", hpos);
    }

    // Scan towards left direction
    thmov += abs(lastt - request[n - 1]);
    printf("Current head position: %d\n", lastt);

    for (int i = n - 2; i >= 0; i--) {
        thmov += abs(request[i] - lastt);
        lastt = request[i];
        printf("Current head position: %d\n", lastt);
    }

    printf("Total head movements: %d\n", thmov);
    return 0;
}
