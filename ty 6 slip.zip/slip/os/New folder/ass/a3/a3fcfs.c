#include <stdio.h>
#include <stdlib.h>

int main() {
    int request[] = {55, 58, 39, 18, 90, 160, 150, 38, 184};
    int n = 9, hpos = 50, thmov = 0;

    printf("Head moved to track %d\n", hpos);

    for (int i = 0; i < n; i++) {
        thmov += abs(request[i] - hpos);
        hpos = request[i];
        printf("Head moved to track %d\n", hpos);
    }

    printf("Total head movements: %d\n", thmov);
    return 0;
}
