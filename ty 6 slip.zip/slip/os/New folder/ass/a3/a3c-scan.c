#include <stdio.h>
#include <stdlib.h>

int main() {
    int request[] = {98, 183, 41, 11, 122, 14, 134, 65, 67};
    int n = 9, hpos = 53, firstt = 0, lastt = 199, thmov = 0;

    // Sort requests in ascending order
    for (int i = 0; i < n - 1; i++)
        for (int j = 0; j < n - i - 1; j++)
            if (request[j] > request[j + 1]) {
                int temp = request[j];
                request[j] = request[j + 1];
                request[j + 1] = temp;
            }

    // Find starting point
    int j = 0;
    while (j < n && request[j] < hpos) j++;

    // Move head to the starting point
    thmov += abs(request[j] - hpos);
    printf("Current head position: %d\n", hpos);

    // Move towards right direction
    for (int i = j; i < n; i++) {
        thmov += abs(request[i] - hpos);
        hpos = request[i];
        printf("Current head position: %d\n", hpos);
    }

    // Move to the end and start again from the beginning
    hpos = lastt;
    thmov += abs(hpos - request[n - 1]);
    printf("Current head position: %d\n", hpos);

    // Move towards the beginning
    hpos = firstt;
    for (int i = 0; i < j; i++) {
        thmov += abs(request[i] - hpos);
        hpos = request[i];
        printf("Current head position: %d\n", hpos);
    }

    printf("Total head movements: %d\n", thmov);
    return 0;
}
